import React from 'react';
import {shallow} from 'enzyme/build';
import App from './App';

//Check if app will crash or not 
it('mounts without crashing', () => {
  const wrapper = shallow(<App />);
  wrapper.unmount()
});
