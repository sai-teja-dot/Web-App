
import Dashboard from './Dashboard';

import { Login } from './Pages';


export {
  Login,
  Dashboard,
};

